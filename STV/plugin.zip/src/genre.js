function execute() {
    return Response.success([
        {title: "Huyền Huyễn", input: "https://sangtacviet.me/?find=&minc=0&category=hh&sort=update&tag=", script: "gen.js"},
        {title: "Đô Thị", input: "https://sangtacviet.me/?find=&minc=0&category=dt&sort=update&tag=", script: "gen.js"},
        {title: "Ngôn Tình", input: "https://sangtacviet.me/?find=&minc=0&category=nt&sort=update&tag=", script: "gen.js"},
        {title: "Võng Du", input: "https://sangtacviet.me/?find=&minc=0&category=vd&sort=update&tag=", script: "gen.js"},
        {title: "Khoa Học Viễn Tưởng", input: "https://sangtacviet.me/?find=&minc=0&category=kh&sort=update&tag=", script: "gen.js"},
        {title: "Dị Năng", input: "https://sangtacviet.me/?find=&minc=0&category=dna&sort=update&tag=", script: "gen.js"},
        {title: "Đồng Nhân", input: "https://sangtacviet.me/?find=&minc=0&category=dn&sort=update&tag=", script: "gen.js"},
        {title: "Linh Dị", input: "https://sangtacviet.me/?find=&minc=0&category=ld&sort=update&tag=", script: "gen.js"},
        {title: "Hoàn thành, > 200c", input: "https://sangtacviet.me/?find=&minc=200&sort=update&step=3&tag=", script: "gen.js"},
        {title: "Hoàn thành, > 500c", input: "https://sangtacviet.me/?find=&minc=500&sort=update&step=3&tag=", script: "gen.js"},
        {title: "H+", input: "https://sangtacviet.me/?find=&findinname=(H+)&minc=0&sort=update&tag=", script: "gen.js"},
    ]);
}